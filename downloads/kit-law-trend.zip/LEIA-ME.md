# Kit Law Trend Academy

Três ferramentas para colocar em prática a palestra sobre IA e a advocacia do futuro.

## Comece por uma tarefa

- **JurisConsulto Digital** — `relatorio-jurisprudencia`, `verificar-precedente` e `auditar-citacoes`. Pesquise, confira e documente evidências em fontes oficiais.
- **Acto Didático** — `registro-aula`, `auditar-registro` e `registro-visual-html`. Organize uma aula ou capacitação, revise a fidelidade e transforme o registro em material visual.
- **Arquiteto de Prompts** — `arquiteto-de-prompts-full`. Transforme um objetivo em instruções reutilizáveis e testáveis.

## ChatGPT · caminho recomendado

1. Abra **Plugins → Skills → Criar → Enviar do computador**.
2. Envie **um ZIP por vez** da pasta `skills/`. Por exemplo, `skills/verificar-precedente.zip`.
3. Abra uma nova conversa e peça a skill pelo nome. A criação e o envio dependem do plano e das permissões do workspace.

[Ajuda do ChatGPT](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

Administradores habilitados também podem importar o plugin completo em **Administração → Plugins → Adicionar → Enviar plugin**, com um ZIP da pasta `plugins/` por vez.

[Administração de plugins do ChatGPT](https://help.openai.com/en/articles/20001256-plugins-in-chatgpt)

No ChatGPT desktop com Codex, extraia o ZIP de um plugin e siga o passo a passo do `LEIA-ME.md` para adicionar seu catálogo local.

## Claude · plugin ou skills avulsas

Para instalar um plugin completo, procure a opção de enviar plugin em **Plugins** (ou **Personalizar**) → **Adicionar**, se disponível. Envie o ZIP de um plugin da pasta `plugins/`, sem extrair esse arquivo. A instalação de plugins exige plano pago e permissões da conta.

Para instalar uma skill avulsa, habilite **execução de código e criação de arquivos** e procure **Enviar skill** na área de Skills da página **Plugins** (ou **Personalizar**). Envie um ZIP por vez da pasta `skills/`.

[Ajuda sobre plugins no Claude](https://support.claude.com/en/articles/13837440-use-plugins-in-claude) · [Ajuda sobre skills no Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude)

## Modo manual · sem instalação

Abra o arquivo da ferramenta em `modo-manual/`, copie as instruções em um novo chat e envie sua tarefa. Se o chat aceitar Markdown, você também pode anexar o `.md` e pedir para seguir o fluxo do arquivo.

Para verificar jurisprudência, use um chat com pesquisa habilitada ou forneça o documento oficial. Revise os resultados antes de citar. Use material de aula autorizado e retire dados pessoais desnecessários.

O ZIP externo do kit serve para distribuir os arquivos. Extraia-o primeiro e escolha o arquivo indicado para sua plataforma.
