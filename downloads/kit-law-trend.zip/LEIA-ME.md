# Kit Law Trend Academy

Três ferramentas para colocar em prática a palestra sobre IA e a advocacia do futuro.

## Comece por uma tarefa

- **JurisConsulto Digital** — `relatorio-jurisprudencia`, `verificar-precedente` e `auditar-citacoes`. Pesquise, confira e documente evidências em fontes oficiais.
- **Acto Didático** — `registro-aula`, `auditar-registro` e `registro-visual-html`. Organize uma aula ou capacitação, revise a fidelidade e transforme o registro em material visual.
- **Arquiteto de Prompts** — `arquiteto-de-prompts-full`. Transforme um objetivo em instruções reutilizáveis e testáveis.

## ChatGPT · caminho recomendado

1. Extraia o ZIP externo do kit.
2. Se a interface oferece **Personalizar → Plugins → Novo plugin**, escolha **um ZIP** da pasta `chatgpt/`, sem extrair esse arquivo. Em workspaces administrados, use **Administração → Plugins → Adicionar → Enviar plugin** quando autorizado.
3. Para enviar somente uma skill, use **Plugins → Habilidades → Criar → Enviar do computador**. Escolha um ZIP da pasta `skills/`.
4. Abra uma nova conversa. Digite `@` e selecione o plugin ou a skill quando aparecer no menu. A disponibilidade depende da conta, do aplicativo e das permissões do workspace.

[Ajuda do ChatGPT](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

[Administração de plugins do ChatGPT](https://help.openai.com/en/articles/20001256-plugins-in-chatgpt)

Para usar o catálogo local do Codex, extraia o arquivo da pasta `codex/` e siga o `LEIA-ME.md` da pasta extraída.

## Claude · plugin ou skills avulsas

Para instalar um plugin completo, procure a opção de enviar plugin em **Personalizar → Plugins → Adicionar**. Se disponível, envie um ZIP da pasta `claude/`, sem extrair esse arquivo. Em uma conversa ou no Cowork, abra `/` para selecionar a skill. A disponibilidade depende da conta e das permissões da organização.

Para instalar uma skill avulsa, habilite **execução de código e criação de arquivos** e procure **Enviar skill** na área de Skills da página **Plugins** (ou **Personalizar**). Envie um ZIP por vez da pasta `skills/`.

[Ajuda sobre plugins no Claude](https://support.claude.com/en/articles/13837440-use-plugins-in-claude) · [Ajuda sobre skills no Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude)

## Modo manual · sem instalação

Abra o arquivo da ferramenta em `modo-manual/`, copie as instruções em um novo chat e envie sua tarefa. Se o chat aceitar Markdown, você também pode anexar o `.md` e pedir para seguir o fluxo do arquivo.

Para verificar jurisprudência, use um chat com pesquisa habilitada ou forneça o documento oficial. Revise os resultados antes de citar. Use material de aula autorizado e retire dados pessoais desnecessários.

O ZIP externo do kit serve para distribuir os arquivos. Extraia-o primeiro e escolha o arquivo indicado para sua plataforma.
