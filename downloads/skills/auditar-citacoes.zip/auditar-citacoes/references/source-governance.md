# Governança de fontes

## Regra principal
Afirmações jurídicas verificáveis exigem fonte primária oficial ou documento oficial fornecido pelo usuário.

## Prioridade
1. STF, STJ, TST e demais tribunais em domínios `.jus.br`.
2. TJAL e tribunal local/preferencial pertinente.
3. Planalto, Diário Oficial e portais legislativos oficiais.
4. Reguladores oficiais quando materialmente relevantes.

## Fontes secundárias
Doutrina, notícias, blogs, agregadores e Jusbrasil podem ser usados apenas como pista de descoberta, salvo pedido expresso. Não substituem a fonte primária.

## Proibições
- Não inventar número, relator, órgão, data ou URL.
- Não usar snippet de busca como prova do teor do julgado.
- Não afirmar jurisprudência pacífica com base em um único acórdão.
- Não preencher quantidade de precedentes artificialmente.
