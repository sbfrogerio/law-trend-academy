# Protocolo de verificação

## Evidence gate
Antes de usar um precedente como fundamento principal, confirmar, quando disponível:
- tribunal;
- classe/recurso;
- número;
- relator(a);
- órgão julgador;
- data de julgamento;
- publicação;
- URL oficial;
- trecho que sustenta a proposição;
- eventual tema, súmula, IRDR ou IAC;
- status posterior relevante.

## Estados
- VERDE: fonte oficial + identidade + trecho de suporte verificados.
- AMARELO: fonte oficial localizada, mas existe lacuna material.
- VERMELHO: referência não localizada, divergente ou sem suporte. Não usar como fundamento principal.

## Status
Use:
- VIGENTE / SEM SUPERAÇÃO LOCALIZADA;
- MODULADO;
- SUPERADO;
- STATUS NÃO CONFIRMADO.

Não transformar ausência de resultado em inexistência.
