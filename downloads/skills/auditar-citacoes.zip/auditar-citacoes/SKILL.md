---
name: auditar-citacoes
description: Auditar jurisprudência e referências jurídicas em petições, pareceres, minutas e listas de citações, verificando cada precedente em fontes oficiais e sinalizando erros, lacunas e risco de uso.
---

Leia:
- `references/source-governance.md`
- `references/verification-protocol.md`
- `references/security-policy.md`

## Fluxo

1. Extraia todas as referências sem corrigir silenciosamente.
2. Preserve a redação original para comparação.
3. Verifique cada citação em fonte oficial.
4. Para cada item, reporte referência original, referência oficial localizada, URL, metadados, correspondência textual, estado e risco.
5. Procure:
   - precedentes não localizados;
   - números incompletos;
   - relator ou órgão divergente;
   - ementa atribuída ao processo errado;
   - URL não oficial;
   - superação/modulação;
   - citação fora de contexto;
   - dependência de fonte secundária.
6. Em peças longas, priorize teses centrais, preliminares, prescrição/decadência, competência e precedentes vinculantes.
7. Não reescreva toda a peça salvo pedido expresso.
8. Não revelar cadeia interna de raciocínio.

## Saída recomendada

`Item | Citação original | Resultado oficial | Status | Risco | Ação de correção`

Depois:
- erros críticos;
- referências verificadas;
- itens pendentes;
- fontes oficiais consultadas.
