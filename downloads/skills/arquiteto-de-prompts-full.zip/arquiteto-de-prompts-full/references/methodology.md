# Metodologia 4-D

Use esta referência em tarefas de modo PADRÃO ou PROFUNDO, especialmente quando houver prompt existente, múltiplas restrições ou alto custo de erro.

## 1. DECOMPOR

Extraia:
- intenção central;
- resultado final;
- usuário/público;
- plataforma ou modelo-alvo;
- contexto disponível;
- entradas;
- saída desejada;
- restrições;
- critérios de sucesso;
- fatos fornecidos;
- informações ausentes.

Diferencie requisito real de preferência estética.

## 2. DIAGNOSTICAR

Verifique:

### Clareza
- verbos vagos;
- termos sem definição;
- sujeito ou público indefinido;
- escopo aberto demais.

### Completude
- entradas necessárias;
- formato de saída;
- critérios de aceitação;
- tratamento de ausência de dados.

### Consistência
- instruções conflitantes;
- prioridades pouco claras;
- limites contraditórios;
- exemplos que contradizem regras.

### Executabilidade
- dependência de ferramenta não garantida;
- pedido impossível de verificar;
- sequência mal ordenada;
- quantidade excessiva de metainstruções.

### Eficiência
- repetição;
- persona desnecessária;
- longas listas sem impacto;
- perguntas que já podem ser respondidas pelo contexto.

## 3. DESENVOLVER

Aplique somente técnicas úteis.

### Criativo
- público;
- objetivo emocional ou comunicacional;
- tom e voz;
- limites de originalidade;
- referências conceituais;
- variações, quando fizer sentido.

### Técnico
- ambiente, versões e interfaces;
- entradas e saídas;
- requisitos funcionais e não funcionais;
- restrições;
- edge cases;
- validação e testes.

### Educacional
- nível do aluno;
- pré-requisitos;
- progressão;
- exemplos;
- exercícios;
- verificação de compreensão.

### Pesquisa/analítico
- questão central;
- critérios;
- evidências;
- comparação de alternativas;
- tratamento de incerteza;
- fontes atuais quando necessárias e disponíveis.

### Operacional
- passos executáveis;
- pontos de decisão;
- condições de parada;
- exceções;
- formato de registro/resultado.

## 4. ENTREGAR

Um prompt de alta qualidade deve:
- funcionar sem contexto oculto;
- preservar a intenção;
- ser proporcional ao problema;
- especificar saída verificável;
- declarar suposições importantes;
- não inventar capacidades;
- reduzir a necessidade de retrabalho.

Prefira clareza a volume.
