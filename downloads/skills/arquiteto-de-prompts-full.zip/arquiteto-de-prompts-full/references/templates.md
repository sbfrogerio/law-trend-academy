# Templates reutilizáveis

## Universal

```text
Papel:
Atue como [especialidade necessária].

Objetivo:
[resultado observável]

Contexto:
[contexto relevante]

Entradas:
[dados fornecidos]

Tarefa:
1. [...]
2. [...]
3. [...]

Restrições:
- [...]
- [...]

Critérios de qualidade:
- [...]
- [...]

Formato de saída:
[estrutura exata]

Incerteza e dados ausentes:
[como proceder]
```

## Técnico

```text
Atue como [especialidade técnica].

Objetivo:
[resultado]

Ambiente:
- stack: [...]
- versões: [...]
- restrições: [...]

Entradas:
[código, logs, requisitos]

Execute:
1. [...]
2. [...]
3. [...]

Valide:
- [...]
- [...]
- [...]

Não assuma:
- [...]

Entregue:
[formato]
```

## Pesquisa

```text
Objetivo:
Responder a [questão] para apoiar [decisão/uso].

Escopo:
- período: [...]
- região/público: [...]
- fontes preferidas: [...]

Método:
1. Separe fatos de interpretação.
2. Verifique informações variáveis em fontes atuais quando houver ferramenta apropriada.
3. Compare evidências relevantes.
4. Declare incertezas e lacunas.

Saída:
- resumo;
- evidências;
- comparação;
- limitações;
- fontes, quando usadas.
```

## Criativo

```text
Atue como [função criativa].

Crie:
[artefato]

Para:
[público]

Objetivo:
[efeito desejado]

Direção:
- tom: [...]
- voz: [...]
- ritmo: [...]
- referências conceituais: [...]

Evite:
- [...]
- [...]

Entregue:
[quantidade e formato]
```

## Revisão de prompt

```text
Revise o prompt abaixo preservando a intenção original.

Avalie:
- clareza;
- completude;
- consistência;
- executabilidade;
- critérios de qualidade;
- formato de saída.

Corrija ambiguidades, conflitos e redundâncias sem inflar o texto.

Entregue:
1. diagnóstico curto;
2. prompt revisado completo;
3. mudanças de maior impacto;
4. 2 testes rápidos.

PROMPT:
[cole aqui]
```
