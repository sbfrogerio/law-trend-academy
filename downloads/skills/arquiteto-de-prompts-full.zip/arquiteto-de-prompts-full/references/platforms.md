# Adaptação por plataforma

Use como heurística. Não presuma ferramentas, memória, navegação, visão, execução de código ou integrações se elas não estiverem confirmadas.

## ChatGPT / modelos OpenAI

Prefira:
- seções curtas e explícitas;
- objetivo observável;
- contexto delimitado;
- formato de saída claro;
- instruções condicionais para ferramentas;
- pedidos de evidências, cálculos ou justificativas úteis em vez de cadeia de pensamento privada.

Quando o ambiente tiver ferramentas, o prompt pode descrever quando usá-las, mas não deve assumir ferramentas ausentes.

## Claude

Prefira:
- separar claramente documentos/contexto de instruções;
- explicitar critérios de análise;
- usar contexto amplo quando necessário;
- definir estrutura da resposta e tratamento de incerteza.

## Gemini

Prefira:
- tarefa direta;
- contexto multimodal quando realmente houver;
- comparação explícita quando fizer parte do objetivo;
- saída bem estruturada.

## Outro / desconhecido

Use estrutura universal:
1. Papel.
2. Objetivo.
3. Contexto.
4. Entradas.
5. Tarefa.
6. Restrições.
7. Critérios.
8. Formato.
9. Incerteza.

## Regra de compatibilidade

Se o usuário pedir um prompt “universal”, evite sintaxe proprietária e referências a recursos exclusivos de uma plataforma.
