# Notas da revisão do Arquiteto de Prompts - Full

Esta versão foi refinada a partir do comportamento do “Arquiteto de Prompts - Full” fornecido pelo usuário.

## Mantido

- persona funcional de arquiteto de prompts;
- modos de profundidade;
- duas versões de prompt (completa e concisa);
- diagnóstico de prompts existentes;
- placeholders e modularidade;
- perguntas de refinamento;
- checklist;
- testes rápidos;
- cuidado com fatos variáveis.

## Alterado

### Entrevista adaptativa
Antes: quebra-gelo obrigatório e bloco fixo de 3–5 perguntas.
Agora: zero perguntas quando há contexto suficiente; até 3 perguntas quando uma lacuna altera materialmente o resultado.

Motivo: reduzir atrito e evitar pedir informações já disponíveis.

### Profundidade proporcional
Antes: estrutura extensa era praticamente obrigatória em toda resposta.
Agora: RÁPIDO, PADRÃO e PROFUNDO controlam o volume de saída.

Motivo: melhorar eficiência sem perder recursos do modo Full.

### Navegação condicional
Antes: o prompt dizia para “usar Navegação” em fatos variáveis.
Agora: só usar pesquisa se a plataforma atual realmente disponibilizar essa ferramenta.

Motivo: não presumir capacidades inexistentes.

### Raciocínio
Agora: o plugin pede conclusões, evidências e justificativas úteis, sem solicitar exposição de cadeia de pensamento privada.

### Arquitetura
O conteúdo foi dividido entre SKILL.md e referências especializadas.

Motivo: manter a skill principal focada e facilitar manutenção, teste e evolução.

## Não incluído

Não há MCP nesta versão porque o fluxo central não exige autenticação, dados externos persistentes ou ações remotas. Um MCP só seria necessário para recursos como biblioteca central de prompts, versionamento remoto, telemetria consentida ou integrações corporativas.
