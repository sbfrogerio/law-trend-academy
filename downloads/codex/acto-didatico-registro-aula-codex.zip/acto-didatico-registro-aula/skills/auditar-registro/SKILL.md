---
name: auditar-registro
description: Revisa registros de aula para detectar invenções, lacunas, inconsistências e problemas de privacidade, clareza e estrutura. Use ao validar ou corrigir um registro existente.
---

# Objetivo

Auditar um REGISTRO DE AULA sem preencher lacunas com fatos inventados.

Consulte:

- `references/modelo-registro-aula.md`
- `references/politica-de-fidelidade.md`
- `references/rubrica-de-auditoria.md`

## Fluxo

1. Identifique o registro a revisar.
2. Se as fontes originais da aula estiverem disponíveis, trate-as como referência principal de fidelidade.
3. Verifique:
   - estrutura;
   - fidelidade;
   - completude;
   - clareza didática;
   - privacidade.
4. Quando houver fonte original, compare afirmações factuais contra ela.
5. Quando não houver fonte original, não declare que fatos estão corretos; limite-se a dizer o que pode ou não ser verificado.
6. Corrija diretamente problemas seguros de forma, organização e clareza.
7. Não invente informações para preencher lacunas.
8. Se o usuário pedir uma versão corrigida, entregue o registro completo corrigido após os achados principais.

## Ordem dos achados

Priorize:
1. problemas que alteram confiabilidade;
2. contradições;
3. campos faltantes;
4. clareza;
5. acabamento editorial.

## Validação determinística

Quando o ambiente permitir execução de scripts, use `scripts/validate_record.py` como verificação estrutural complementar.

O script não substitui a auditoria semântica.
