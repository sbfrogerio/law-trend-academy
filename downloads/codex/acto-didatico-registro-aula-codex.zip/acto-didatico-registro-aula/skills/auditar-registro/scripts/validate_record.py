#!/usr/bin/env python3
"""Validação estrutural offline de um REGISTRO DE AULA em Markdown."""

from __future__ import annotations
from pathlib import Path
import re
import sys

REQUIRED_SECTIONS = [
    "1. DADOS DE CATALOGAÇÃO",
    "2. OBJETIVO(S) DE APRENDIZAGEM",
    "3. RESUMO DO CONTEÚDO EXPOSTO",
    "4. PONTOS-CHAVE E CONCEITOS DE ATENÇÃO",
    "5. CONEXÕES CURRICULARES",
    "6. MATERIAIS PARA APROFUNDAMENTO E ESTUDO",
    "7. TAREFAS E PRÓXIMOS PASSOS",
    "8. AVISOS E OBSERVAÇÕES GERAIS",
]

PLACEHOLDER_PATTERNS = [
    r"\[Inserir\b",
    r"\[Tópico\s+\d+\]",
    r"\[Desenvolvimento\b",
    r"\[DD/MM/AAAA\]",
    r"\[valor confirmado",
    r"\[objetivo observável",
]

def validate_text(text: str) -> list[str]:
    issues: list[str] = []

    positions: list[int] = []
    for section in REQUIRED_SECTIONS:
        pos = text.find(section)
        if pos < 0:
            issues.append(f"Seção ausente: {section}")
        positions.append(pos)

    present = [p for p in positions if p >= 0]
    if len(present) > 1 and present != sorted(present):
        issues.append("As seções obrigatórias estão fora de ordem.")

    for pattern in PLACEHOLDER_PATTERNS:
        if re.search(pattern, text, flags=re.I):
            issues.append(f"Placeholder residual detectado: {pattern}")

    section7 = text.find("7. TAREFAS E PRÓXIMOS PASSOS")
    section8 = text.find("8. AVISOS E OBSERVAÇÕES GERAIS")
    if section7 >= 0:
        block = text[section7:section8 if section8 > section7 else None]
        if "|" not in block:
            issues.append("A seção 7 não parece conter uma tabela Markdown.")

    if "Responsável pelo registro" not in text:
        issues.append("Identificação do responsável pelo registro não detectada.")

    visual_prompt = "Você quer transformar este registro em"
    if text.count(visual_prompt) != 1:
        issues.append("A pergunta final de transformação visual deve aparecer exatamente uma vez.")

    return issues

def main() -> int:
    if len(sys.argv) != 2:
        print("Uso: python scripts/validate_record.py <arquivo.md>")
        return 2

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Arquivo não encontrado: {path}")
        return 2

    issues = validate_text(path.read_text(encoding="utf-8"))
    if issues:
        print("FALHOU")
        for issue in issues:
            print(f"- {issue}")
        return 1

    print("OK — estrutura básica do REGISTRO DE AULA validada.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
