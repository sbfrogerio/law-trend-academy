# REGISTRO DE AULA

## 1. DADOS DE CATALOGAÇÃO

- **Disciplina:** [valor confirmado ou “Não informado no material disponibilizado.”]
- **Professor(a):** [valor confirmado ou “Não informado no material disponibilizado.”]
- **Data / Horário:** [valor confirmado ou “Não informado no material disponibilizado.”]
- **Turma / Período:** [valor confirmado ou “Não informado no material disponibilizado.”]
- **Tema Central da Aula:** [tema principal identificado no conteúdo]

## 2. OBJETIVO(S) DE APRENDIZAGEM

Descreva o que o aluno deve ser capaz de fazer, saber ou compreender ao final da aula.

- [objetivo observável 1]
- [objetivo observável 2]
- [objetivo 3 somente se necessário]

## 3. RESUMO DO CONTEÚDO EXPOSTO

Produza um resumo narrativo e didático em sequência lógica.

### 3.1. [Título do tópico]
[Desenvolvimento fiel ao material]

### 3.2. [Título do tópico]
[Desenvolvimento fiel ao material]

Adicione 3.3, 3.4 etc. somente quando o conteúdo justificar.

## 4. PONTOS-CHAVE E CONCEITOS DE ATENÇÃO

Use apenas subitens aplicáveis:

- **Fórmula Essencial:** [fórmula presente no material e significado]
- **Atenção:** [distinção, erro comum ou condição relevante]
- **Conceito Crítico:** [conceito central]

Quando um tipo de destaque não existir, não invente. Pode registrar “Não identificado no material.”

## 5. CONEXÕES CURRICULARES

- **Tópico Anterior Relacionado:** [informado ou “Não informado no material disponibilizado.”]
- **Prepara para o Próximo Tópico:** [informado ou “Não informado no material disponibilizado.”]

## 6. MATERIAIS PARA APROFUNDAMENTO E ESTUDO

- **Leituras Obrigatórias:** [somente as explicitamente indicadas]
- **Leituras Complementares:** [somente as explicitamente indicadas]
- **Vídeos / Links Úteis:** [somente os citados]

Se o usuário pediu pesquisa externa, mantenha as recomendações em um bloco separado intitulado **Sugestões complementares**.

## 7. TAREFAS E PRÓXIMOS PASSOS

| Tarefa | Instruções Breves | Prazo de Entrega |
|---|---|---|
| [tarefa confirmada ou “Nenhuma tarefa informada”] | [instruções ou “—”] | [prazo ou “Não informado”] |

## 8. AVISOS E OBSERVAÇÕES GERAIS

[avisos confirmados; se nenhum, “Nenhum aviso geral informado.”]

**Responsável pelo registro:** [nome fornecido ou “Não informado”]  
**Função:** Tutor Acadêmico / Assistente Pedagógico
