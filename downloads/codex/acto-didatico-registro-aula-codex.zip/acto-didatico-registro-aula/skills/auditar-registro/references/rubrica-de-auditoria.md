# Rubrica de auditoria

## Estrutura
- oito seções presentes;
- ordem correta;
- headings legíveis;
- tabela de tarefas;
- identificação do responsável.

## Fidelidade
Procure especialmente:
- datas e prazos não sustentados;
- tarefas inventadas;
- bibliografia marcada como obrigatória sem fonte;
- “próximo tópico” inventado;
- links não presentes;
- resultados experimentais inventados;
- conceitos externos introduzidos como conteúdo da aula.

## Completude
- metadados conhecidos preenchidos;
- ausências explicitamente marcadas;
- tarefas tratadas mesmo quando inexistentes;
- avisos tratados mesmo quando inexistentes.

## Clareza didática
- objetivos coerentes;
- sequência lógica;
- títulos informativos;
- pouca redundância;
- destaque apropriado de fórmulas e conceitos críticos.

## Privacidade
- sem nomes de estudantes incidentais;
- sem informações pessoais sem necessidade.

## Regra de correção
Corrija forma e organização quando for seguro.
Para conteúdo factual sem fonte, use “Não informado” ou sinalize impossibilidade de verificação.
