# Política de fidelidade, inferência e proveniência

## 1. Fatos administrativos — nunca inferir

Incluem:

- disciplina;
- professor(a);
- data e horário;
- turma/período;
- tarefas;
- trabalhos;
- avaliações;
- prazos;
- datas de prova;
- alterações de cronograma;
- avisos;
- leituras obrigatórias;
- materiais oficialmente indicados.

Se estiverem ausentes, registre como não informados.

## 2. Conteúdo acadêmico — reorganizar sem ampliar silenciosamente

Conceitos, fórmulas, argumentos, exemplos e procedimentos podem ser:

- resumidos;
- reordenados;
- explicados em linguagem mais clara;
- agrupados em tópicos.

Não acrescente conhecimento externo como se tivesse sido ensinado na aula.

## 3. Objetivos de aprendizagem — síntese permitida

É permitido derivar objetivos a partir do conteúdo efetivamente abordado.

Prefira verbos observáveis:
- identificar;
- explicar;
- diferenciar;
- comparar;
- aplicar;
- analisar;
- interpretar;
- relacionar.

Não crie objetivos dependentes de conteúdo ausente.

## 4. Conexões curriculares — somente com suporte

“Tópico anterior relacionado” e “próximo tópico” só podem ser preenchidos quando houver:

- menção explícita no material; ou
- confirmação do usuário.

Caso contrário, use “Não informado no material disponibilizado.”

## 5. Materiais de estudo

Classifique corretamente:

- **Leitura obrigatória:** somente se explicitamente indicada.
- **Leitura complementar:** somente se explicitamente indicada.
- **Sugestão complementar:** recomendação externa criada após pedido do usuário.

Nunca transforme uma sugestão do assistente em obrigação acadêmica.

## 6. Conflitos

Prioridade das fontes:

1. correção/confirmacão explícita mais recente do usuário;
2. transcrição, tópicos ou arquivo original;
3. síntese/inferência pedagógica permitida.

Se duas fontes do usuário permanecerem contraditórias e não houver correção clara, registre a incerteza em vez de escolher silenciosamente uma delas.

## 7. Privacidade

O registro de aula é um artefato pedagógico, não um prontuário individual.

Por padrão, omita:
- nomes de estudantes mencionados incidentalmente;
- contatos;
- notas individuais;
- observações pessoais sem relevância pedagógica;
- informações sensíveis de participantes.

Preserve dados pessoais apenas quando o usuário pedir e eles forem necessários para a finalidade legítima do documento.
