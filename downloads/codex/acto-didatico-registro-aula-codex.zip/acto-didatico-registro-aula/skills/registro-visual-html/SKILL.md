---
name: registro-visual-html
description: Transforma um registro de aula consolidado em apresentação, guia interativo ou documento visual em HTML. Use para produzir material de estudo ou apresentação.
---

# Objetivo

Criar um arquivo HTML autocontido, profissional, responsivo e acessível a partir de um REGISTRO DE AULA já consolidado.

Consulte:

- `references/especificacao-html.md`
- `assets/base.css`
- `assets/presentation.js` quando o modo for apresentação.

# Modos

## A. Apresentação / guia interativo

Use quando o usuário pedir slides, apresentação, guia navegável ou estudo interativo.

Estrutura sugerida:
1. capa;
2. objetivos;
3. visão geral;
4. tópicos da aula;
5. pontos-chave;
6. tarefas e avisos;
7. revisão final/checklist.

Inclua navegação anterior/próximo e teclado quando houver JavaScript.

## B. Documento visual profissional

Use quando o usuário pedir handout, apostila curta, documento visual, página de estudo ou registro com design.

Estrutura sugerida:
1. cabeçalho com metadados;
2. objetivos em cards;
3. conteúdo em blocos;
4. conceitos de atenção;
5. conexões curriculares;
6. materiais;
7. tabela de tarefas;
8. avisos;
9. rodapé.

# Regras

- Não introduza conteúdo acadêmico novo.
- Preserve tarefas, prazos e avisos exatamente como constam no registro.
- Gere HTML que funcione localmente.
- Não use CDNs, fontes remotas, analytics ou scripts de terceiros.
- Use `lang="pt-BR"`.
- Use elementos semânticos (`main`, `section`, headings, `table`).
- Inclua CSS responsivo e regras de impressão.
- Garanta foco visível e contraste suficiente.
- Não dependa apenas de cor para transmitir significado.
- Respeite `prefers-reduced-motion`.
- O conteúdo deve continuar legível se JavaScript falhar.

# Entrega

Quando houver capacidade de criar arquivos, entregue um `.html` em vez de apenas mostrar o código.
