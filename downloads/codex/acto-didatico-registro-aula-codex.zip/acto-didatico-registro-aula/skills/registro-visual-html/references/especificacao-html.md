# Especificação de saída HTML

## Requisitos gerais

- arquivo único `.html`;
- abre localmente em navegador moderno;
- sem dependências remotas;
- sem rastreamento;
- sem formulários que enviem dados;
- responsivo;
- imprimível.

## Acessibilidade

- `lang="pt-BR"`;
- ordem de headings coerente;
- foco visível em elementos interativos;
- controles com rótulos acessíveis;
- tabelas com `<thead>`;
- conteúdo compreensível sem cor;
- suporte a `prefers-reduced-motion`.

## Impressão

Para documento visual:
- `@media print`;
- evitar sombras desnecessárias;
- impedir quebra dentro de cards quando possível;
- ocultar controles de navegação.

## Apresentação

Quando houver modo apresentação:
- cada slide deve ser um `<section>`;
- navegação por botões;
- atalhos: setas, PageUp/PageDown, Home/End;
- contador de slides;
- JavaScript progressivo: sem JS, todos os conteúdos continuam acessíveis.

## Segurança

Não incorporar:
- scripts de terceiros;
- iframes externos sem pedido explícito;
- analytics;
- pixels;
- chamadas de rede.
