(() => {
  const slides = [...document.querySelectorAll('[data-slide]')];
  if (!slides.length) return;

  let index = 0;

  function show(nextIndex) {
    index = Math.max(0, Math.min(slides.length - 1, nextIndex));
    slides.forEach((slide, i) => {
      slide.hidden = i !== index;
    });

    const counter = document.querySelector('[data-counter]');
    if (counter) counter.textContent = `${index + 1} / ${slides.length}`;

    const active = slides[index];
    if (active) {
      active.setAttribute('tabindex', '-1');
      active.focus({ preventScroll: true });
    }
  }

  document.querySelector('[data-prev]')?.addEventListener('click', () => show(index - 1));
  document.querySelector('[data-next]')?.addEventListener('click', () => show(index + 1));

  addEventListener('keydown', (event) => {
    if (['ArrowRight', 'PageDown', ' '].includes(event.key)) show(index + 1);
    if (['ArrowLeft', 'PageUp'].includes(event.key)) show(index - 1);
    if (event.key === 'Home') show(0);
    if (event.key === 'End') show(slides.length - 1);
  });

  show(0);
})();
