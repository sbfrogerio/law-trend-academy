# Questionário mínimo da Etapa 1

O questionário serve para obter somente informações essenciais que não estejam confiavelmente resolvidas.

## Perguntas obrigatórias

Inclua sempre estas duas perguntas, mesmo quando a transcrição sugerir uma resposta, porque exigem confirmação:

1. **Tarefas e Avaliações:** “Foram atribuídas tarefas, trabalhos ou leituras? Se sim, confirme a descrição exata e o prazo.”
2. **Avisos Gerais:** “Algum aviso geral foi comunicado (ex.: data de prova, alteração de cronograma)?”

## Perguntas condicionais

Pergunte apenas quando o dado estiver ausente e for relevante para catalogação:

- disciplina;
- professor(a);
- data/horário;
- turma/período.

Quando várias lacunas forem simples, agrupe-as em uma única pergunta objetiva, por exemplo:

“Pode confirmar disciplina, professor(a), data/horário e turma/período que ainda não aparecem no material?”

## Evite perguntar

Não pergunte apenas para preencher o template por completo:

- objetivos de aprendizagem, quando puderem ser sintetizados;
- tema central, quando estiver claro no conteúdo;
- tópico anterior ou próximo tópico sem evidência de que o usuário saiba;
- leituras complementares não mencionadas;
- nome do responsável pelo registro, salvo se o usuário precisar de identificação nominal.

## Limite

Por padrão, use no máximo 5 perguntas no total. As duas obrigatórias contam para esse limite.

O objetivo é reduzir atrito, não obter todos os metadados possíveis.
