# Classificação da modalidade da aula

Escolha sempre uma modalidade principal entre as quatro permitidas.

## Expositiva

Use quando a ação dominante é apresentação, explicação, demonstração conceitual ou exposição estruturada conduzida pelo docente.

Indícios frequentes:
- definições e explicações;
- sequência teórica;
- exemplos usados para esclarecer conceitos;
- participação discente principalmente por perguntas pontuais.

## Prática/Laboratório

Use quando o núcleo é executar procedimento, experimento, técnica, montagem, observação prática ou atividade de campo/laboratório.

Indícios frequentes:
- materiais e equipamentos;
- passo a passo operacional;
- coleta/observação de resultados;
- treino de técnica;
- interpretação de dados produzidos na atividade.

## Seminário/Debate

Use quando apresentação discente, discussão, argumentação ou confronto de perspectivas é o núcleo da aula.

Indícios frequentes:
- apresentação de grupos;
- perguntas, réplicas e contrapontos;
- discussão de teses ou textos;
- mediação docente do debate.

## Revisão/Exercícios

Use quando o objetivo dominante é consolidar conteúdo já trabalhado por meio de revisão, resolução, correção, estudo dirigido ou preparação para avaliação.

Indícios frequentes:
- listas de exercícios;
- correção coletiva;
- retomada explícita de conteúdo;
- questões de prova ou simulado;
- treino de aplicação.

## Regra para aulas híbridas

Não crie categoria “mista”.

Escolha a modalidade que melhor representa a **ação pedagógica central**, usando estes critérios em ordem:

1. Qual atividade ocupa o núcleo do encontro?
2. O que os estudantes fazem durante a maior parte do trabalho pedagógico?
3. Qual atividade organiza os conteúdos recuperáveis da transcrição?

Se necessário, a justificativa pode mencionar elementos secundários de outra modalidade, mas a classificação final continua única.
