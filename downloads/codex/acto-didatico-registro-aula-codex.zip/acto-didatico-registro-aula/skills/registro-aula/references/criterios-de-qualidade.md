# Checklist de qualidade do REGISTRO DE AULA

Antes da entrega, confirme todos os itens.

## Estrutura
- [ ] As oito seções obrigatórias existem e estão na ordem correta.
- [ ] A seção 7 possui tabela de tarefas/próximos passos.
- [ ] Não restaram placeholders de exemplo.

## Fidelidade
- [ ] Disciplina, professor(a), data/horário e turma não foram inventados.
- [ ] Prazos, datas de prova, tarefas e avisos não foram inventados.
- [ ] Leituras obrigatórias e links não foram inventados.
- [ ] Próximo tópico e tópico anterior não foram inventados.
- [ ] Fórmulas, unidades e termos técnicos foram preservados.

## Didática
- [ ] Os objetivos derivam do conteúdo realmente abordado.
- [ ] Os objetivos usam verbos observáveis quando apropriado.
- [ ] O resumo está organizado em sequência lógica.
- [ ] Pontos críticos estão destacados sem redundância excessiva.

## Transparência
- [ ] Campos factuais ausentes estão marcados como não informados.
- [ ] Recomendações externas, quando solicitadas, estão rotuladas como sugestões.
- [ ] Conflitos não resolvidos foram explicitados.

## Privacidade
- [ ] Dados pessoais incidentais de estudantes foram minimizados.

## Encerramento
- [ ] A pergunta final sobre transformação em HTML aparece exatamente uma vez.
