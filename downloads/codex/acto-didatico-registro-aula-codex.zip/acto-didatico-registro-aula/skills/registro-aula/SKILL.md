---
name: registro-aula
description: Transforma transcrições e anotações de aula em um registro pedagógico fiel, com um questionário breve antes da redação. Use para organizar ou documentar aulas e capacitações.
---

# Missão

Transformar material bruto de uma aula em um registro pedagógico claro, estudável e auditável, sem inventar fatos ausentes.

As instruções explícitas do usuário prevalecem sobre os padrões desta skill, exceto quando exigiriam apresentar como fato algo que não é sustentado pelo material.

## Recursos que devem ser consultados

Antes de executar o fluxo, use estes arquivos quando forem relevantes:

- `references/classificacao-de-aula.md`
- `references/questionario-minimo.md`
- `references/politica-de-fidelidade.md`
- `references/modelo-registro-aula.md`
- `references/criterios-de-qualidade.md`

## Entradas aceitas

Aceite uma ou mais destas fontes:

- transcrição integral;
- tópicos ou anotações;
- texto extraído de imagem/arquivo;
- disciplina, professor(a), data/horário e turma/período;
- respostas posteriores ao questionário;
- registro já existente que o usuário queira refazer.

Não exija um formato específico quando o conteúdo puder ser interpretado com segurança.

# Fluxo obrigatório

## ETAPA 1 — análise e questionário

1. Extraia fatos explicitamente presentes no material.
2. Identifique metadados disponíveis e ausentes.
3. Classifique a aula em uma modalidade principal:
   - **Expositiva**
   - **Prática/Laboratório**
   - **Seminário/Debate**
   - **Revisão/Exercícios**
4. Em aula híbrida, escolha a modalidade dominante segundo `classificacao-de-aula.md`. Não crie uma quinta categoria.
5. Gere um questionário mínimo usando `questionario-minimo.md`.
6. Inclua sempre as duas perguntas obrigatórias sobre tarefas/avaliações e avisos gerais.
7. Faça perguntas adicionais somente quando a lacuna for importante para o registro e não puder ser inferida de forma segura.
8. Por padrão, use no máximo 5 perguntas no total.
9. Pare ao fim do questionário. **Não gere o REGISTRO DE AULA na Etapa 1.**

### Saída da Etapa 1

Use exatamente esta organização:

**Classificação da aula:** <modalidade>

**Justificativa breve:** <uma frase baseada no material>

**Questionário**
1. ...
2. ...

Não inclua resumo final, registro parcial, bibliografia sugerida ou HTML.

## ETAPA 2 — geração do registro

Inicie quando o usuário responder ao questionário, inclusive se alguma resposta for “não”, “não sei” ou “não informado”.

1. Reúna novamente:
   - material original;
   - metadados originais;
   - respostas da Etapa 1.
2. Resolva conflitos de informação nesta ordem:
   - correção ou confirmação explícita mais recente do usuário;
   - conteúdo da transcrição/anotações;
   - inferência pedagógica permitida.
3. Redija o documento na ordem e com os títulos de `modelo-registro-aula.md`.
4. Aplique a política de fidelidade de `politica-de-fidelidade.md`.
5. Onde um fato administrativo estiver ausente, use “Não informado no material disponibilizado.” ou formulação curta equivalente.
6. Objetivos de aprendizagem podem ser sintetizados a partir do que foi efetivamente ensinado, usando verbos observáveis.
7. O resumo deve preservar termos técnicos, relações causais, etapas, fórmulas, unidades e distinções conceituais presentes no material.
8. Não invente tópico anterior, próximo tópico, leitura obrigatória, link, prazo ou aviso.
9. Materiais externos só podem ser acrescentados se o usuário pedir pesquisa/complementação. Nesse caso, rotule-os como **Sugestão complementar**.
10. Tarefas e prazos devem reproduzir fielmente a confirmação do usuário.
11. Avisos devem reproduzir somente o que foi informado/confirmado.
12. Minimize dados pessoais de estudantes que não sejam necessários para a finalidade pedagógica.
13. Revise a saída segundo `criterios-de-qualidade.md`.

## Encerramento obrigatório da Etapa 2

Depois do registro, faça apenas esta pergunta curta:

**Você quer transformar este registro em (a) uma apresentação/guia interativo em HTML ou (b) um documento visual profissional em HTML?**

Se o usuário escolher uma das opções, use a skill `registro-visual-html` quando estiver disponível. Se a instalação incluir somente esta skill, indique o ZIP avulso de `registro-visual-html`.

# Regra central de confiabilidade

Quando faltar informação, marque a ausência. Não “complete” o documento com fatos plausíveis.
