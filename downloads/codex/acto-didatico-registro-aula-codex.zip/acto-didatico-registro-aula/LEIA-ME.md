# Acto Didático · Registro de Aula · 2.1.0

Edição do kit Law Trend Academy, com as skills e os recursos operacionais da versão indicada.

## Skills incluídas

- `auditar-registro`
- `registro-aula`
- `registro-visual-html`

## Catálogo local · ChatGPT desktop com Codex

1. Extraia o ZIP. A pasta `acto-didatico-registro-aula` contém o catálogo `.agents/plugins/marketplace.json`.
2. Se você usa a CLI do Codex, execute `codex plugin marketplace add "caminho/para/acto-didatico-registro-aula"` com o caminho da pasta extraída.
3. Reinicie o ChatGPT desktop, abra o diretório de Plugins em Work ou Codex, selecione **Acto Didático · Registro de Aula · Kit Law Trend** como origem e instale o plugin.

[Documentação do catálogo local no Codex](https://developers.openai.com/plugins/build/plugins)
