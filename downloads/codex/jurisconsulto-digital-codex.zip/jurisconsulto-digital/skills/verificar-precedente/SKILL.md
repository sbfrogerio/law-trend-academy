---
name: verificar-precedente
description: Confirmar a existência, identidade, metadados, texto citado, URL oficial e status pesquisável de um precedente jurídico brasileiro.
---

Leia:
- `references/source-governance.md`
- `references/verification-protocol.md`
- `references/security-policy.md`

## Procedimento

1. Parseie somente os dados fornecidos pelo usuário.
2. Pesquise a referência na fonte oficial correspondente.
3. Abra a página ou documento oficial antes de confirmar.
4. Compare os metadados campo a campo.
5. Se houver citação literal, confirme o texto no documento.
6. Pesquise eventual status posterior quando materialmente relevante.
7. Classifique como VERDE, AMARELO ou VERMELHO.
8. Nunca transformar "não encontrei" em "não existe".
9. Não revelar cadeia interna de raciocínio.

## Saída
- referência fornecida;
- referência confirmada;
- URL oficial;
- campos coincidentes;
- campos divergentes;
- citação textual: confere / não confere / não foi possível verificar;
- status;
- verificação;
- pendências antes de citar.
