# Relatório de Jurisprudência Estratégica

## Tese analisada
Uma frase objetiva com a questão jurídica pesquisada.

## Escopo da pesquisa
- fatos juridicamente relevantes;
- tribunais;
- período;
- termos principais;
- data da pesquisa.

## Resultado executivo
Síntese factual do que foi localizado, sem promessa de resultado processual.

## 1. Jurisprudência favorável

Para cada julgado:
- Referência completa
- Categoria normativa
- Força operacional (1–5)
- Similitude fático-jurídica
- Verificação: VERDE / AMARELO
- Status
- Ementa/trecho oficial, somente se recuperado
- URL oficial
- Síntese da ratio
- Pertinência para o caso
- Aspecto da tese reforçado
- Uso argumentativo possível
- Risco/distinguishing previsível

## 2. Jurisprudência adversa
Mesmos metadados, acrescidos de:
- tese adversa;
- uso provável pela parte contrária;
- distinções verificáveis;
- limite da refutação.

Se não localizada, declarar isso expressamente.

## 3. Matriz de risco
Registrar conflito, divergência, fatos ainda não provados, precedente antigo, status não confirmado e alterações posteriores.

## 4. Candidatos descartados
Listar precedentes rejeitados e o motivo.

## 5. Trilha de evidências
Listar consultas principais, domínios, filtros, URLs e lacunas.
