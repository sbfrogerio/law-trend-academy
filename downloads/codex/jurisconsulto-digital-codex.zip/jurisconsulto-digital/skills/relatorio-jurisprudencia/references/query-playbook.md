# Playbook de pesquisa

## Decomposição
Extraia:
- instituto jurídico;
- relação material;
- fato central;
- consequência jurídica;
- exceções;
- competência;
- sinônimos.

## Famílias de consulta
Autoridade:
- `<instituto> tema repetitivo`
- `<instituto> repercussão geral`
- `<instituto> súmula`
- `<instituto> IRDR IAC`

Fato:
- `<instituto> <fato central> <efeito>`

Adversa:
- `<instituto> não configurado`
- `<instituto> inaplicável`
- `<instituto> ausência de <efeito>`

Temporal:
- `superado`
- `modulação`
- `revisão`
- `afetado`
- `tema`

Resultado de busca é candidato. Só vira precedente utilizável após abertura e conferência da fonte oficial.
