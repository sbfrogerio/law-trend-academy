# Arquiteto de Prompts · Full · 2.0.0

Edição do kit Law Trend Academy, com as skills e os recursos operacionais da versão indicada.

## Skills incluídas

- `arquiteto-de-prompts-full`

## Catálogo local · ChatGPT desktop com Codex

1. Extraia o ZIP. A pasta `arquiteto-de-prompts-full` contém o catálogo `.agents/plugins/marketplace.json`.
2. Se você usa a CLI do Codex, execute `codex plugin marketplace add "caminho/para/arquiteto-de-prompts-full"` com o caminho da pasta extraída.
3. Reinicie o ChatGPT desktop, abra o diretório de Plugins em Work ou Codex, selecione **Arquiteto de Prompts · Full · Kit Law Trend** como origem e instale o plugin.

[Documentação do catálogo local no Codex](https://developers.openai.com/plugins/build/plugins)
