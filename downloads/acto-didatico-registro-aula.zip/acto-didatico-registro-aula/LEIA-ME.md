# Acto Didático · Registro de Aula · 2.1.0

Edição do kit Law Trend Academy, com as skills e os recursos operacionais da versão indicada.

## Skills incluídas

- `auditar-registro`
- `registro-aula`
- `registro-visual-html`

## Use no ChatGPT ou no Claude

No ChatGPT, quem administra um workspace habilitado pode enviar este ZIP em **Administração → Plugins → Adicionar → Enviar plugin**. Para instalar skills individualmente, baixe o ZIP de cada skill na página do kit. No ChatGPT, abra **Plugins → Skills → Criar → Enviar do computador** quando a opção estiver disponível.

[Ajuda sobre plugins no ChatGPT](https://help.openai.com/en/articles/20001256-plugins-in-chatgpt) · [Ajuda sobre skills no ChatGPT](https://help.openai.com/en/articles/20001066-skills-in-chatgpt)

## Catálogo local · ChatGPT desktop com Codex

1. Extraia o ZIP. A pasta `acto-didatico-registro-aula` contém o catálogo `.agents/plugins/marketplace.json`.
2. Se você usa a CLI do Codex, execute `codex plugin marketplace add "caminho/para/acto-didatico-registro-aula"` com o caminho da pasta extraída.
3. Reinicie o ChatGPT desktop, abra o diretório de Plugins em Work ou Codex, selecione **Acto Didático · Registro de Aula · Kit Law Trend** como origem e instale o plugin.

[Documentação do catálogo local no Codex](https://developers.openai.com/plugins/build/plugins)

## Claude · plano pago habilitado

No Claude, em planos pagos habilitados, procure a opção de enviar plugin em **Plugins** (ou **Personalizar**) → **Adicionar** e escolha o ZIP completo. Para envio de skills avulsas, use o ZIP individual e a opção **Enviar skill** na área de Skills.

[Ajuda sobre plugins no Claude](https://support.claude.com/en/articles/13837440-use-plugins-in-claude)
